<?php

namespace App\Livewire\POS;

use Livewire\Component;

class POSSettings extends Component
{
    public function render()
    {
        return view('livewire.p-o-s.p-o-s-settings');
    }
}
